import { db } from "../firebase-config.js";

import {
    collection,
    addDoc,
    getDocs,
    query,
    where,
    serverTimestamp
}
from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

import {
    doc,
    updateDoc
}
from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

export async function createDrawBox(boxData) {

    const existingBoxes =
    await getGroupBoxes(
        boxData.groupId
    );

    const boxNumber =
    existingBoxes.length + 1;

    boxData.boxNumber =
    boxNumber;

    boxData.displayNumber =
    String(boxNumber)
    .padStart(2, "0");
    
    boxData.month = null;

boxData.year = null;

boxData.picked = false;

boxData.locked = false;

boxData.reserved = false;

boxData.reservedBy = null;

boxData.pickedBy = null;

boxData.pickedAt = null;

boxData.lockedBy = null;

boxData.lockedAt = null;

    boxData.createdAt =
    serverTimestamp();

    boxData.status =
    "Available";

    const docRef =
    await addDoc(

        collection(
            db,
            "drawBoxes"
        ),

        boxData

    );

    return docRef.id;

}

export async function getGroupBoxes(groupId) {

    const q = query(

        collection(
            db,
            "drawBoxes"
        ),

        where(
            "groupId",
            "==",
            groupId
        )

    );

    const snapshot = await getDocs(q);

    const boxes = [];

    snapshot.forEach(doc => {

        boxes.push({

            id: doc.id,

            ...doc.data()

        });

    });

    return boxes;

}

export async function updateBoxAssignment(

    boxId,

    month,

    year

) {

    await updateDoc(

        doc(
            db,
            "drawBoxes",
            boxId
        ),

        {

            month,

            year,

            status: "Ready"

        }

    );

}

export async function revealDrawBox(

    boxId

) {

    await updateDoc(

        doc(
            db,
            "drawBoxes",
            boxId
        ),

        {

            status: "Picked",

            locked: true,

            lockedAt: serverTimestamp()

        }

    );

}