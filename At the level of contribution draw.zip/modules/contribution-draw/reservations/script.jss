import {
    getGroupBoxes
}
from "../../../js/services/drawBoxService.js";

const params =
new URLSearchParams(
    window.location.search
);

const groupId =
params.get("id");

const monthsContainer =
document.getElementById(
    "monthsContainer"
);

async function loadMonths() {

    if (!groupId) {

        monthsContainer.innerHTML =
        "No draw group selected.";

        return;

    }

    try {

        const boxes =
        await getGroupBoxes(
            groupId
        );

        if (boxes.length === 0) {

            monthsContainer.innerHTML =
            "No prepared boxes found.";

            return;

        }

        monthsContainer.innerHTML = "";

        boxes.forEach(box => {

            monthsContainer.innerHTML += `

            <div class="month-card">

                <h3>

                ${box.month} ${box.year}

                </h3>

                <button>

                Reserve

                </button>

            </div>

            `;

        });

    }

    catch(error) {

        console.error(error);

        monthsContainer.innerHTML =
        "Unable to load months.";

    }

}

loadMonths();