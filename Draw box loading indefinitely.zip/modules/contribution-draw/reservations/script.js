import {
    getGroupBoxes,
    reserveMonth
}
from "../../../js/services/drawBoxService.js";

const params =
new URLSearchParams(
    window.location.search
);

const groupId =
params.get("id");

const monthsContainer =
document.getElementById(
    "monthsContainer"
);

async function handleReservation(event) {

    const button = event.target;

    const boxId =
    button.dataset.boxId;

    const month =
    button.dataset.month;

    const year =
    button.dataset.year;

    try {

    // Replace with your authenticated admin ID later
    const adminId = "ADMIN";

    await reserveMonth(

        boxId,

        adminId

    );

    button.textContent = "Reserved";

    button.disabled = true;

}

catch(error) {

    console.error(error);

    alert("Unable to reserve month.");

}

}

async function loadMonths() {

    if (!groupId) {

        monthsContainer.innerHTML =
        "No draw group selected.";

        return;

    }

    try {

        const boxes =
        await getGroupBoxes(
            groupId
        );

        if (boxes.length === 0) {

            monthsContainer.innerHTML =
            "No prepared boxes found.";

            return;

        }

        monthsContainer.innerHTML = "";

        boxes.forEach(box => {

    monthsContainer.innerHTML += `

    <div class="month-card">

        <h3>

        ${box.month} ${box.year}

        </h3>

        <button
    class="reserve-btn"
    data-box-id="${box.id}"
    data-month="${box.month}"
    data-year="${box.year}"
    ${box.reserved ? "disabled" : ""}>

    ${box.reserved ? "Reserved" : "Reserve"}

</button>

    </div>

    `;

});

document.querySelectorAll(".reserve-btn")
.forEach(button => {

    button.addEventListener(
        "click",
        handleReservation
    );

});

}

catch(error) {

    console.error(error);

    monthsContainer.innerHTML =
    "Unable to load months.";

}

}

loadMonths();