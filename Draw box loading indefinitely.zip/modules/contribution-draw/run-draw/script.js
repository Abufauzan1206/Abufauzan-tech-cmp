import {

    getGroupBoxes,

    getDrawBox,

    revealDrawBox

}
from "../../../js/services/drawBoxService.js";

const params =
new URLSearchParams(
window.location.search
);

const groupId =
params.get("id");

const boxesContainer =
document.getElementById(
"boxesContainer"
);

// Temporary.
// Will later come from Firebase Authentication.

const currentUser = {

    id: "USER",

    role: "participant"

};

async function handleBoxClick(event){

    const boxId =

    event.currentTarget.dataset.boxId;
    
    console.log("Clicked:", boxId);

    const box =

await getDrawBox(boxId);

console.log(box);

if(!box){

    return;

}

if(

    box.reserved &&

    currentUser.role !== "admin"

){

    alert("Reserved box");

    return;

}

{

    // Reserved month.
    // Participants see nothing.

    return;

}

    try{

    await revealDrawBox(

        boxId,

        currentUser.id

    );

}catch(error){

    console.error(error);

    alert(error.message);

    return;

}

event.currentTarget.innerHTML = `

<div
class="revealed-month">

${box.month}

</div>

<div
class="revealed-year">

${box.year}

</div>

`;

event.currentTarget.classList.add(

    "locked"

);

}

async function loadBoxes(){

    if(!groupId){

        boxesContainer.innerHTML =
        "No draw group selected.";

        return;

    }

    const boxes =
    await getGroupBoxes(
        groupId
    );

    boxesContainer.innerHTML="";

    boxes.forEach(box=>{

        boxesContainer.innerHTML +=`

      boxesContainer.innerHTML += `

<div
class="draw-box"
onclick="alert('Clicked')"
data-box-id="${box.id}">

<div class="gift-icon">

🎁

</div>

<div class="box-number">

${box.displayNumber}

</div>

</div>

`;

    });
    
    document
.querySelectorAll(".draw-box")
.forEach(box=>{

    box.addEventListener(

        "click",

        handleBoxClick

    );

});

}

loadBoxes();