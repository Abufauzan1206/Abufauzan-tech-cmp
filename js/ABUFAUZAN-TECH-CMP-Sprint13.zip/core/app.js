/**
 * =====================================================
 * ABUFAUZAN TECH Cooperative Management Platform
 * Core Framework
 *
 * File: app.js
 * Module: CMP Core Application Controller
 * Version: 1.0.0
 * =====================================================
 */
 import { CMPFrameworkInitializer } from "./frameworkInitializer.js";
 
 import { CMPServiceRegistry } from "./serviceRegistry.js";
import { CMPLoggerService } from "./loggerService.js";
import { CMPHealthService } from "./healthService.js";

import { CMPServiceRegistry } from "./serviceRegistry.js";

class CMPApp {

    constructor() {

        this.name = "ABUFAUZAN TECH CMP";

        this.version = "2.0.0-dev";

        this.environment = "development";

        this.initialized = false;
        
this.services = {};

this.modules = {};

this.user = null;

this.organization = null;

    }


    /**
     * Initialize CMP Platform
     */
   async init() {

    await CMPFrameworkInitializer.initialize();

    try {

        await this.loadFramework();

        this.initialized = true;

        CMPLoggerService.log(
    "info",
    "CMP Framework initialized successfully."
);

    } catch (error) {

        this.handleError(error);

    }

}


    /**
     * Load core framework components
     */
    async loadFramework() {


        console.log(
            "Loading CMP Core Framework..."
        );
        
        CMPServiceRegistry.initialize();
        
        /*
            Future loading sequence:

            1. Firebase
            2. Authentication
            3. Session Manager
            4. Organization Context
            5. Permission Engine
            6. Notification Service

        */

    }
    
    /**
 * Register a core service
 */
registerService(name, service) {

    this.services[name] = service;

}

/**
 * Get a registered service
 */
getService(name) {

    return this.services[name];

}

/**
 * Register a platform module
 */
registerModule(name, module) {

    this.modules[name] = module;

}

/**
 * Get a registered module
 */
getModule(name) {

    return this.modules[name];

}

    /**
     * Global error handler
     */
    handleError(error) {


        console.error(
            "CMP Framework Error:",
            error
        );


    }

}


// Create global CMP application instance

export const CMP = new CMPApp();


// Auto start application

CMP.init();