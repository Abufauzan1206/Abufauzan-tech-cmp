export const menuData = [

  {
    title: "Dashboard",
    icon: "🏠",
    url: "super-admin.html"
  },

  {
    title: "Register Cooperative",
    icon: "🏢",
    url: "register-cooperative.html"
  },

  {
    title: "Cooperatives",
    icon: "🏢",
    url: "#"
  },

  {
    title: "Members",
    icon: "👥",
    url: "modules/members/index.html"
  },

  {
    title: "Contributions",
    icon: "💰",
    url: "#"
  },

  {
    title: "Loans",
    icon: "🏦",
    url: "#"
  },

  {
    title: "Welfare",
    icon: "❤️",
    url: "#"
  },

  {
    title: "Investments",
    icon: "📈",
    url: "#"
  },

  {
    title: "Marketplace",
    icon: "🛒",
    url: "#"
  },

  {
    title: "Reports",
    icon: "📊",
    url: "#"
  },

  {
    title: "Users",
    icon: "👤",
    url: "#"
  },

  {
    title: "Settings",
    icon: "⚙️",
    url: "#"
  }

];