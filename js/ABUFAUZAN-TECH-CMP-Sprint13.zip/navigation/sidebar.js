import { menuData } from "./menu-data.js";

export function buildSidebar(containerId) {

  const container = document.getElementById(containerId);

  if (!container) return;

  container.innerHTML = "";

  menuData.forEach(menu => {

    const link = document.createElement("a");

    link.href = menu.url;

    link.textContent = menu.icon + " " + menu.title;

    link.className = "sidebar-link";

    container.appendChild(link);

  });

}